/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package it.unisa.diem.se.automationapp.action.exception;

/**
 *
 * @author chiar
 */
public class AudioExecutionException extends Exception{

    public AudioExecutionException() {
    }

    public AudioExecutionException(String msg) {
        super(msg);
    }
    
    
}
